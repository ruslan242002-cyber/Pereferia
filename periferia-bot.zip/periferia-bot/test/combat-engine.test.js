'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  clamp, critChance, basicAttack, useSkill, applyStim, tickPeriodic, resolveTurn
} = require('../engine/combat-engine.js');
const { scriptedRng } = require('../engine/seeded-rng.js');
const { SKILLS, STIMS } = require('../engine/skills-data.js');

function fighter(overrides = {}) {
  return {
    name: 'Тест',
    hp: 200, hpMax: 200,
    stats: { power: 20, mind: 20, reaction: 20, endurance: 20, firepower: 30, shielding: 20 },
    luck: 10, accuracy: 0.8, dodge: 0.1, focus: 0.75,
    periodic: [],
    ...overrides
  };
}

test('clamp держит значение в границах', () => {
  assert.equal(clamp(5, 0, 10), 5);
  assert.equal(clamp(-5, 0, 10), 0);
  assert.equal(clamp(15, 0, 10), 10);
});

test('critChance растёт с удачей, но капается на 60%', () => {
  assert.equal(critChance(0), 0.05);
  assert.ok(critChance(1000) <= 0.6);
});

test('basicAttack: промах при высоком броске', () => {
  const a = fighter(); const d = fighter();
  // acc = 0.8 - 0.1 = 0.7; rng() = 0.99 > 0.7 → промах
  const rng = scriptedRng([0.99]);
  const res = basicAttack(a, d, rng);
  assert.equal(res.hit, false);
  assert.equal(res.dmg, 0);
});

test('basicAttack: попадание без крита считает урон корректно с учётом экранирования', () => {
  const a = fighter(); const d = fighter({ stats: { ...fighter().stats, shielding: 50 } });
  // первый rng() < 0.7 → попадание; второй rng() (крит-ролл) = 0.9 > critChance → без крита
  const rng = scriptedRng([0.1, 0.9]);
  const res = basicAttack(a, d, rng);
  const expectedBase = a.stats.firepower * 0.6 + a.stats.power * 0.4; // 30*0.6+20*0.4=26
  const expected = Math.round(expectedBase * (1 - 50 / 100));
  assert.equal(res.hit, true);
  assert.equal(res.crit, false);
  assert.equal(res.dmg, expected);
});

test('basicAttack: крит применяет множитель 1.5', () => {
  const a = fighter(); const d = fighter({ stats: { ...fighter().stats, shielding: 0 } });
  const rng = scriptedRng([0.1, 0.01]); // попадание, затем крит (0.01 < critChance)
  const res = basicAttack(a, d, rng);
  const base = a.stats.firepower * 0.6 + a.stats.power * 0.4;
  assert.equal(res.crit, true);
  assert.equal(res.dmg, Math.round(base * 1.5));
});

test('экранирование капается на 85% — урон никогда не падает до нуля от брони', () => {
  const a = fighter(); const d = fighter({ stats: { ...fighter().stats, shielding: 999 } });
  const rng = scriptedRng([0.1, 0.9]);
  const res = basicAttack(a, d, rng);
  assert.ok(res.dmg > 0, 'урон должен оставаться положительным даже при экстремальной броне');
});

test('useSkill: чистый урон (pure) игнорирует экранирование', () => {
  const a = fighter();
  const d = fighter({ stats: { ...fighter().stats, shielding: 80 } });
  const rng = scriptedRng([0.1, 0.9]); // попадание по фокусу, без крита
  const res = useSkill(a, d, SKILLS.anima_drain, rng);
  const base = a.stats.reaction * 0.7 + a.stats.endurance * 0.5 + a.stats.power * 0.6;
  assert.equal(res.dmg, Math.round(base)); // экранирование не применяется — pure:true
});

test('useSkill: lifesteal лечит атакующего пропорционально урону', () => {
  const a = fighter();
  const d = fighter();
  const rng = scriptedRng([0.1, 0.9]);
  const res = useSkill(a, d, SKILLS.anima_drain, rng);
  assert.equal(res.heal, Math.round(res.dmg * 0.25));
});

test('useSkill: selfHealPct лечит от hpMax независимо от урона', () => {
  const a = fighter({ hpMax: 300 });
  const d = fighter();
  const rng = scriptedRng([0.1, 0.9]);
  const res = useSkill(a, d, SKILLS.living_heat, rng);
  assert.equal(res.heal, Math.round(300 * 0.15));
});

test('useSkill: промах по фокусу не наносит урон и не лечит', () => {
  const a = fighter({ focus: 0.5 });
  const d = fighter();
  const rng = scriptedRng([0.99]);
  const res = useSkill(a, d, SKILLS.plasma_bolt, rng);
  assert.equal(res.hit, false);
  assert.equal(res.dmg, 0);
  assert.equal(res.heal, 0);
});

test('applyStim: heal не поднимает HP выше hpMax', () => {
  const t = fighter({ hp: 195, hpMax: 200 });
  applyStim(t, STIMS.emergency_stim);
  assert.equal(t.hp, 200);
});

test('applyStim: hpMultiplier увеличивает и текущее, и максимальное HP', () => {
  const t = fighter({ hp: 100, hpMax: 100 });
  applyStim(t, STIMS.exo_frame);
  assert.equal(t.hpMax, 150);
  assert.equal(t.hp, 150);
});

test('applyStim: applyDot добавляет периодический эффект в очередь', () => {
  const t = fighter({ periodic: [] });
  applyStim(t, STIMS.nano_regen);
  assert.equal(t.periodic.length, 1);
  assert.equal(t.periodic[0].type, 'hot');
});

test('tickPeriodic: DoT наносит урон и затухает на 30%', () => {
  const t = fighter({ hp: 200, hpMax: 200, periodic: [{ type: 'dot', amount: 20, turnsLeft: 3 }] });
  const res = tickPeriodic(t);
  assert.equal(res.totalDot, 20);
  assert.equal(t.hp, 180);
  assert.equal(t.periodic[0].amount, 14); // 20 * 0.7
  assert.equal(t.periodic[0].turnsLeft, 2);
});

test('tickPeriodic: эффект удаляется, когда turnsLeft истёк', () => {
  const t = fighter({ periodic: [{ type: 'dot', amount: 5, turnsLeft: 1 }] });
  tickPeriodic(t);
  assert.equal(t.periodic.length, 0);
});

test('tickPeriodic: HoT лечит, но не выше hpMax', () => {
  const t = fighter({ hp: 195, hpMax: 200, periodic: [{ type: 'hot', amount: 50, turnsLeft: 2 }] });
  tickPeriodic(t);
  assert.equal(t.hp, 200);
});

test('resolveTurn: полный ход с обычной атакой определяет победителя при hp<=0', () => {
  const a = fighter({ stats: { power: 999, mind: 10, reaction: 10, endurance: 10, firepower: 999, shielding: 0 } });
  const d = fighter({ hp: 10, hpMax: 200 });
  const rng = scriptedRng([0.01, 0.9]); // гарантированное попадание, без крита
  const result = resolveTurn({ attacker: a, defender: d, rng });
  assert.equal(result.finished, true);
  assert.equal(result.winner, 'attacker');
  assert.equal(d.hp, 0);
});

test('resolveTurn: HP никогда не уходит в минус', () => {
  const a = fighter({ stats: { power: 9999, mind: 10, reaction: 10, endurance: 10, firepower: 9999, shielding: 0 } });
  const d = fighter({ hp: 5, hpMax: 200 });
  const rng = scriptedRng([0.01, 0.9]);
  resolveTurn({ attacker: a, defender: d, rng });
  assert.ok(d.hp >= 0);
});

test('resolveTurn: стим применяется до фазы атаки в этом же ходу (лечение видно сразу)', () => {
  const a = fighter({ hp: 100, hpMax: 200 });
  const d = fighter();
  const rng = scriptedRng([0.99, 0.9]); // атака промахнётся, но стим должен всё равно сработать
  const result = resolveTurn({ attacker: a, defender: d, stim: STIMS.field_stim, rng });
  assert.ok(a.hp > 100, 'стим должен вылечить атакующего в том же ходу, даже если атака промахнулась');
});

test('resolveTurn: outgoing-модификатор от стима увеличивает итоговый урон', () => {
  const withMod = fighter();
  applyStim(withMod, STIMS.overclock); // ×1.25 исходящего и ×1.25 входящего (на себя же, для этого теста неважно)
  const targetA = fighter();
  const rngA = scriptedRng([0.1, 0.9]);
  const resultA = resolveTurn({ attacker: withMod, defender: targetA, rng: rngA });

  const plain = fighter();
  const targetB = fighter();
  const rngB = scriptedRng([0.1, 0.9]);
  const resultB = resolveTurn({ attacker: plain, defender: targetB, rng: rngB });

  assert.ok(targetA.hp < targetB.hp, 'цель атакующего с оверклоком должна получить больше урона на идентичном броске dice');
});
