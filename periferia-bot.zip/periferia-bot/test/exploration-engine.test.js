'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { rollEvent, rollLoot, RESOURCES } = require('../engine/exploration-engine.js');
const { scriptedRng, makeRng } = require('../engine/seeded-rng.js');

test('rollLoot: ресурс всегда из известного списка', () => {
  const rng = makeRng(42);
  for (let i = 0; i < 200; i++) {
    const loot = rollLoot('yellow', rng);
    assert.ok(RESOURCES.includes(loot.resource));
  }
});

test('rollLoot: тир для синей зоны всегда в диапазоне 1-2', () => {
  const rng = makeRng(7);
  for (let i = 0; i < 200; i++) {
    const loot = rollLoot('blue', rng);
    assert.ok(loot.tier >= 1 && loot.tier <= 2, `tier ${loot.tier} вне диапазона синей зоны`);
  }
});

test('rollLoot: тир для красной зоны всегда в диапазоне 4-7', () => {
  const rng = makeRng(99);
  for (let i = 0; i < 200; i++) {
    const loot = rollLoot('red', rng);
    assert.ok(loot.tier >= 4 && loot.tier <= 7, `tier ${loot.tier} вне диапазона красной зоны`);
  }
});

test('rollLoot: количество и кредиты всегда положительные целые', () => {
  const rng = makeRng(1);
  for (let i = 0; i < 100; i++) {
    const loot = rollLoot('red', rng);
    assert.ok(Number.isInteger(loot.qty) && loot.qty >= 1);
    assert.ok(Number.isInteger(loot.credits) && loot.credits >= 0);
  }
});

test('rollEvent: маленький roll всегда попадает в первую категорию весов (find)', () => {
  const rng = scriptedRng([0.001, 0.1, 0.1]); // очень маленький — гарантированно в первый диапазон "find"
  const ev = rollEvent('blue', rng);
  assert.equal(ev.type, 'find');
  assert.ok(ev.loot);
});

test('rollEvent: распределение по красной зоне даёт заметно больше засад, чем по синей', () => {
  const rngRed = makeRng(2024);
  const rngBlue = makeRng(2024);
  let ambushRed = 0, ambushBlue = 0;
  const N = 2000;
  for (let i = 0; i < N; i++) {
    if (rollEvent('red', rngRed).type === 'ambush') ambushRed++;
    if (rollEvent('blue', rngBlue).type === 'ambush') ambushBlue++;
  }
  assert.ok(ambushRed > ambushBlue, `красная зона (${ambushRed}) должна давать больше засад, чем синяя (${ambushBlue})`);
});

test('rollEvent ambush: HP врага положительное и растёт с опасностью зоны в среднем', () => {
  const rng = makeRng(5);
  let sumBlue = 0, sumRed = 0, nBlue = 0, nRed = 0;
  for (let i = 0; i < 500; i++) {
    const evB = rollEvent('blue', rng);
    if (evB.type === 'ambush') { sumBlue += evB.enemy.hp; nBlue++; assert.ok(evB.enemy.hp > 0); }
    const evR = rollEvent('red', rng);
    if (evR.type === 'ambush') { sumRed += evR.enemy.hp; nRed++; assert.ok(evR.enemy.hp > 0); }
  }
  if (nBlue > 0 && nRed > 0) {
    assert.ok(sumRed / nRed > sumBlue / nBlue, 'средний HP отголоска в красной зоне должен быть выше, чем в синей');
  }
});
