'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const server = require('../webhook/server.js');

function post(path, payload) {
  return new Promise((resolve, reject) => {
    server.listen(0, () => {
      const { port } = server.address();
      const data = JSON.stringify(payload);
      const req = http.request(
        { host: 'localhost', port, path, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } },
        (res) => {
          let raw = '';
          res.on('data', (c) => (raw += c));
          res.on('end', () => {
            server.close();
            try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); }
            catch (e) { reject(e); }
          });
        }
      );
      req.on('error', reject);
      req.write(data);
      req.end();
    });
  });
}

function samplePlayer() {
  return {
    hp: 200, hpMax: 200,
    stats: { power: 25, mind: 22, reaction: 24, endurance: 28, firepower: 30, shielding: 20 },
    luck: 12, accuracy: 0.8, dodge: 0.12, focus: 0.76, periodic: []
  };
}
function sampleEnemy() {
  return {
    hp: 150, hpMax: 150,
    stats: { power: 18, mind: 16, reaction: 18, endurance: 20, firepower: 22, shielding: 15 },
    luck: 8, accuracy: 0.7, dodge: 0.08, focus: 0.6, periodic: []
  };
}

test('POST /api/turn: обычная атака возвращает лог и обновлённый state', async () => {
  const res = await post('/api/turn', {
    action: 'attack',
    state: { player: samplePlayer(), enemy: sampleEnemy() }
  });
  assert.equal(res.status, 200);
  assert.ok(typeof res.body.log === 'string' && res.body.log.length > 0);
  assert.ok(res.body.state.player && res.body.state.enemy);
  assert.ok(res.body.state.enemy.hp <= 150);
});

test('POST /api/turn: навык с неизвестным id возвращает понятную ошибку, а не падение сервера', async () => {
  const res = await post('/api/turn', {
    action: 'skill', skillId: 'not_a_real_skill',
    state: { player: samplePlayer(), enemy: sampleEnemy() }
  });
  assert.equal(res.status, 200);
  assert.ok(res.body.error);
});

test('POST /api/turn: без state возвращает ошибку, а не 500', async () => {
  const res = await post('/api/turn', { action: 'attack' });
  assert.equal(res.status, 200);
  assert.ok(res.body.error);
});

test('POST /api/turn: стим лечит атакующего даже без skillId', async () => {
  const player = samplePlayer(); player.hp = 100;
  const res = await post('/api/turn', {
    action: 'attack', stimId: 'field_stim',
    state: { player, enemy: sampleEnemy() }
  });
  assert.ok(res.body.state.player.hp > 100);
});

test('POST /api/explore: возвращает событие с текстом, готовым для подстановки в шаблон', async () => {
  const res = await post('/api/explore', { zone: 'yellow' });
  assert.equal(res.status, 200);
  assert.ok(res.body.type);
  assert.ok(typeof res.body.text === 'string' && res.body.text.length > 0);
});

test('GET-запрос отклоняется с 405, а не падает сервер', async () => {
  const result = await new Promise((resolve, reject) => {
    server.listen(0, () => {
      const { port } = server.address();
      const req = http.request({ host: 'localhost', port, path: '/api/turn', method: 'GET' }, (res) => {
        res.on('data', () => {});
        res.on('end', () => { server.close(); resolve(res.statusCode); });
      });
      req.on('error', reject);
      req.end();
    });
  });
  assert.equal(result, 405);
});
