/**
 * Локальный сервер для проверки на своей машине ДО деплоя на Vercel.
 * Ноль зависимостей — только встроенный модуль http.
 * Запуск: node webhook/server.js
 * Проверка: curl-примеры лежат в webhook/curl-examples.sh
 */
'use strict';
const http = require('http');
const { route } = require('./handler.js');

const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
  if (req.method !== 'POST') {
    res.writeHead(405, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Используйте POST' }));
    return;
  }
  let body = '';
  req.on('data', (chunk) => { body += chunk; });
  req.on('end', () => {
    let parsed;
    try {
      parsed = body ? JSON.parse(body) : {};
    } catch (e) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Некорректный JSON в теле запроса' }));
      return;
    }
    const result = route(req.url, parsed);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(result));
  });
});

if (require.main === module) {
  server.listen(PORT, () => console.log(`Локальный сервер запущен: http://localhost:${PORT}`));
}

module.exports = server;
