import "../styles/page.css";
import "./Community.css";

export default function Community() {
  return (
    <div className="page">
      <h1>СООБЩЕСТВО</h1>
      <p>Обсуждай, предлагай, создавай будущее Периферии вместе с нами.</p>

      <div className="socials">
        {/* TODO: заменить на реальные ссылки сообществ, когда они будут под рукой */}
        <a href="https://vk.com/periferia_mmo" target="_blank" rel="noreferrer">VK</a>
        <a href="https://discord.gg/periferia" target="_blank" rel="noreferrer">DS</a>
        <a href="https://t.me/periferia_mmo" target="_blank" rel="noreferrer">TG</a>
      </div>
    </div>
  );
}
