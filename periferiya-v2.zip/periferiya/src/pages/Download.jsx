import "../styles/page.css";

export default function Download() {
  return (
    <div className="page">
      <h1>НАЧАТЬ ИГРУ</h1>
      <p>
        «Периферия» — текстовая MMO, играть можно прямо в браузере или через
        VK Mini App. Здесь появится ссылка на запуск игры.
      </p>
      <div className="page__soon">Раздел в разработке</div>
    </div>
  );
}
