import "../styles/page.css";

export default function Login() {
  return (
    <div className="page">
      <h1>ВХОД</h1>
      <p>Здесь появится форма входа в личный кабинет игрока.</p>
      <div className="page__soon">Раздел в разработке</div>
    </div>
  );
}
