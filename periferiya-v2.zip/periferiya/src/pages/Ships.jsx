import "../styles/page.css";

export default function Ships() {
  return (
    <div className="page">
      <h1>КОРАБЛИ</h1>
      <p>
        Здесь появится каталог кораблей: классы, характеристики и то, как их
        получить и модернизировать в игре.
      </p>
      <div className="page__soon">Раздел в разработке</div>
    </div>
  );
}
