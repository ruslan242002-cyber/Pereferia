import "../styles/page.css";

export default function World() {
  return (
    <div className="page">
      <h1>МИР</h1>
      <p>
        Здесь появится лор галактики «Периферия»: карта секторов, история
        известных систем и описание того, что делает этот мир живым.
      </p>
      <div className="page__soon">Раздел в разработке</div>
    </div>
  );
}
