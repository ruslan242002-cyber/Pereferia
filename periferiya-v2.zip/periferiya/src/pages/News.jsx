import "../styles/page.css";
import "./News.css";

const news = [
  ["Обновление «Хроники Периферии»", "12.05.2024"],
  ["Новый игровой сезон", "01.05.2024"],
  ["Изменения в механике боёв", "20.04.2024"],
];

export default function News() {
  return (
    <div className="page">
      <h1>НОВОСТИ</h1>
      <p>Последние обновления и события галактики «Периферия».</p>

      <div className="newsList">
        {news.map(([title, date]) => (
          <div className="newsList__row" key={title}>
            <span>
              <i />
              {title}
            </span>
            <time>{date}</time>
          </div>
        ))}
      </div>
    </div>
  );
}
