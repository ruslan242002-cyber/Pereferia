import "../styles/page.css";

export default function Register() {
  return (
    <div className="page">
      <h1>РЕГИСТРАЦИЯ</h1>
      <p>Здесь появится форма регистрации нового игрока.</p>
      <div className="page__soon">Раздел в разработке</div>
    </div>
  );
}
