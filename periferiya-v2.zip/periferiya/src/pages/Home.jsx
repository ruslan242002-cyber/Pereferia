import Hero from "../components/Hero";
import About from "../components/About";
import Stats from "../components/Stats";
import Mechanics from "../components/Mechanics";

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <Stats />
      <Mechanics />
    </>
  );
}
