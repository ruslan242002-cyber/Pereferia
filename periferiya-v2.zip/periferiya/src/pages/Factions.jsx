import "../styles/page.css";

export default function Factions() {
  return (
    <div className="page">
      <h1>ФРАКЦИИ</h1>
      <p>
        Здесь появятся описания фракций «Периферии»: их идеология, территории
        и то, как игроки могут к ним присоединиться.
      </p>
      <div className="page__soon">Раздел в разработке</div>
    </div>
  );
}
