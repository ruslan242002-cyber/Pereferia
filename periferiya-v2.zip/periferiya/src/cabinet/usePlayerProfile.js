import { useEffect, useState, useCallback } from "react";
import { API_BASE_URL } from "../config";

// api/profile.js -> lib/profile-handler.js -> resolvePeerId() проверяет
// подпись launch-параметров через VK_MINI_APP_SECRET.
// GET  ?launch=<query>            -> { player, allSkills, maxEquippedSkills }
// POST body: { launchParams, action, ...payload } -> { player } | { error }
// Важно: имя поля в теле POST — "launchParams" (не "launch", как в query
// GET-запроса) — так читает его resolvePeerId() в profile-handler.js.
export function usePlayerProfile(launchParams) {
  const [player, setPlayer] = useState(null);
  const [allSkills, setAllSkills] = useState(null);
  const [maxEquippedSkills, setMaxEquippedSkills] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!launchParams) {
      setLoading(false);
      setError("no-launch-params");
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);

    fetch(`${API_BASE_URL}/profile?launch=${encodeURIComponent(launchParams)}`)
      .then(async (res) => {
        const json = await res.json();
        if (!res.ok) throw new Error(json?.error || `HTTP ${res.status}`);
        return json;
      })
      .then((json) => {
        if (cancelled) return;
        setPlayer(json.player);
        setAllSkills(json.allSkills || null);
        setMaxEquippedSkills(json.maxEquippedSkills ?? null);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || "fetch-failed");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [launchParams]);

  // Общая точка для allocateStat / setEquippedSkills — обе бьют в один и
  // тот же POST /api/profile с разным action, и обе в ответ получают
  // свежий player целиком, которым просто заменяем локальный стейт.
  const postAction = useCallback(
    async (action, payload = {}) => {
      if (!launchParams) return { ok: false, error: "no-launch-params" };
      try {
        const res = await fetch(`${API_BASE_URL}/profile`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ launchParams, action, ...payload }),
        });
        const json = await res.json();
        if (!res.ok) return { ok: false, error: json?.error || `HTTP ${res.status}` };
        setPlayer(json.player);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: err.message || "fetch-failed" };
      }
    },
    [launchParams]
  );

  const allocateStat = useCallback(
    (stat) => postAction("allocateStat", { stat }),
    [postAction]
  );

  const setEquippedSkills = useCallback(
    (skillIds) => postAction("setEquippedSkills", { skillIds }),
    [postAction]
  );

  return {
    player,
    allSkills,
    maxEquippedSkills,
    loading,
    error,
    allocateStat,
    setEquippedSkills,
  };
}
