import { NavLink } from "react-router-dom";
import { useEffect } from "react";
import {
  User,
  Map,
  Store,
  Layers,
  Trophy,
  Users,
  BookOpen,
  Settings,
} from "lucide-react";
import "./CabinetSidebar.css";

const CABINET_LINKS = [
  { to: "/cabinet", label: "Профиль", icon: User, end: true },
  { to: "/cabinet/map", label: "Карта", icon: Map },
  { to: "/cabinet/shop", label: "Магазин", icon: Store },
  { to: "/cabinet/workbench", label: "Технический стол", icon: Layers },
  { to: "/cabinet/ratings", label: "Рейтинги", icon: Trophy },
  { to: "/cabinet/guilds", label: "Фракции", icon: Users },
  { to: "/cabinet/codex", label: "Справочник", icon: BookOpen },
];

export default function CabinetSidebar({ open, onClose }) {
  // Закрыть по Escape — тот же паттерн, что и в мобильном меню Navbar.
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <>
      <aside className={`cabinetSidebar ${open ? "cabinetSidebar--open" : ""}`}>
        <div className="cabinetSidebar__brand">
          <span>ПЕРИФЕРИЯ</span>
          <em>v0.1.0-beta</em>
        </div>

        <nav className="cabinetSidebar__nav">
          {CABINET_LINKS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) =>
                `cabinetSidebar__link ${isActive ? "cabinetSidebar__link--active" : ""}`
              }
            >
              <Icon size={20} strokeWidth={1.75} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <NavLink
          to="/cabinet/settings"
          onClick={onClose}
          className={({ isActive }) =>
            `cabinetSidebar__link cabinetSidebar__link--settings ${
              isActive ? "cabinetSidebar__link--active" : ""
            }`
          }
        >
          <Settings size={20} strokeWidth={1.75} />
          <span>Настройки</span>
        </NavLink>
      </aside>

      {open && <div className="cabinetSidebar__overlay" onClick={onClose} />}
    </>
  );
}
