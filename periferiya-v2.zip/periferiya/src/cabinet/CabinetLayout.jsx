import { useState } from "react";
import { Outlet } from "react-router-dom";
import { Menu } from "lucide-react";
import CabinetSidebar from "./CabinetSidebar";
import "./CabinetLayout.css";

export default function CabinetLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="cabinet">
      <CabinetSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="cabinet__main">
        <header className="cabinet__topbar">
          <button
            type="button"
            className="cabinet__menuButton"
            onClick={() => setSidebarOpen(true)}
            aria-label="Открыть меню"
          >
            <Menu size={22} />
          </button>
          <span className="cabinet__topbarTitle">ПЕРИФЕРИЯ</span>
        </header>

        <div className="cabinet__content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
