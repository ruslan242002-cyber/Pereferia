import "./CabinetPlaceholder.css";

export default function CabinetCodex() {
  return (
    <div className="cabinetPlaceholder">
      <h1>СПРАВОЧНИК</h1>
      <p>База знаний по миру: бестиарий, лор станций, история и хроники.</p>
      <div className="cabinetPlaceholder__soon">Раздел в разработке</div>
    </div>
  );
}
