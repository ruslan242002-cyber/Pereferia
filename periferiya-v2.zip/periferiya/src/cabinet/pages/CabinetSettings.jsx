import "./CabinetPlaceholder.css";

export default function CabinetSettings() {
  return (
    <div className="cabinetPlaceholder">
      <h1>НАСТРОЙКИ</h1>
      <p>Настройки аккаунта, уведомлений и профиля.</p>
      <div className="cabinetPlaceholder__soon">Раздел в разработке</div>
    </div>
  );
}
