import "./CabinetPlaceholder.css";

export default function CabinetMap() {
  return (
    <div className="cabinetPlaceholder">
      <h1>КАРТА</h1>
      <p>Интерактивная карта секторов и станций «Периферии» — с текущим положением персонажа и доступными переходами.</p>
      <div className="cabinetPlaceholder__soon">Раздел в разработке</div>
    </div>
  );
}
