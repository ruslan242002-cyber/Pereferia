import "./CabinetPlaceholder.css";

export default function CabinetWorkbench() {
  return (
    <div className="cabinetPlaceholder">
      <h1>ТЕХНИЧЕСКИЙ СТОЛ</h1>
      <p>Крафт, апгрейд снаряжения и работа с ресурсами.</p>
      <div className="cabinetPlaceholder__soon">Раздел в разработке</div>
    </div>
  );
}
