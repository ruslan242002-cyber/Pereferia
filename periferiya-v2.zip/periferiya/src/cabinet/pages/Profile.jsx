import { useState } from "react";
import { useVkLaunchParams } from "../useVkLaunchParams";
import { usePlayerProfile } from "../usePlayerProfile";
import "./Profile.css";

// Совпадает с формулой из engine/leveling.js (50+25*(level-1)).
// Лучше со временем отдавать nextLevelXp готовым полем из api/profile.js,
// чтобы формула не могла разъехаться между фронтом и бэком.
function xpToNext(level) {
  return 50 + 25 * (level - 1);
}

const ZONE_LABEL = {
  blue: "Патрулируемый сектор",
  yellow: "Спорный сектор",
  red: "Открытый космос",
};

const STAT_LABELS = {
  power: "Сила",
  mind: "Разум",
  reaction: "Реакция",
  endurance: "Выносливость",
};

export default function Profile() {
  const { raw: launchParams, hasVkUserId } = useVkLaunchParams();
  const {
    player,
    allSkills,
    maxEquippedSkills,
    loading,
    error,
    allocateStat,
    setEquippedSkills,
  } = usePlayerProfile(hasVkUserId ? launchParams : null);

  const [statBusy, setStatBusy] = useState(null); // какой стат сейчас сохраняется
  const [skillsOpen, setSkillsOpen] = useState(false);
  const [skillSelection, setSkillSelection] = useState([]);
  const [skillsBusy, setSkillsBusy] = useState(false);
  const [skillsError, setSkillsError] = useState(null);

  if (loading) {
    return (
      <div className="profile">
        <p className="profile__state">Загрузка профиля...</p>
      </div>
    );
  }

  if (!hasVkUserId || error === "no-launch-params") {
    return (
      <div className="profile">
        <p className="profile__state">
          Не удалось определить игрока — открой личный кабинет через
          VK Mini App, чтобы увидеть профиль.
        </p>
      </div>
    );
  }

  if (error && error.includes("ещё не создан")) {
    return (
      <div className="profile">
        <p className="profile__state">
          Профиль ещё не создан — начни игру в сообществе ВК, потом
          возвращайся сюда.
        </p>
      </div>
    );
  }

  if (error || !player) {
    return (
      <div className="profile">
        <p className="profile__state profile__state--error">
          Не удалось загрузить профиль. Попробуй обновить страницу.
        </p>
      </div>
    );
  }

  const next = xpToNext(player.level || 1);
  const xpPercent = Math.min(100, Math.round(((player.xp || 0) / next) * 100));
  const equippedSkillNames = (player.equippedSkills || [])
    .map((id) => allSkills?.find((s) => s.id === id)?.name || id);

  async function handleAllocate(stat) {
    setStatBusy(stat);
    await allocateStat(stat);
    setStatBusy(null);
  }

  function openSkillEditor() {
    setSkillSelection(player.equippedSkills || []);
    setSkillsError(null);
    setSkillsOpen(true);
  }

  function toggleSkill(id) {
    setSkillSelection((prev) => {
      if (prev.includes(id)) return prev.filter((s) => s !== id);
      if (prev.length >= (maxEquippedSkills || 3)) return prev; // лимит достигнут
      return [...prev, id];
    });
  }

  async function saveSkills() {
    setSkillsBusy(true);
    setSkillsError(null);
    const result = await setEquippedSkills(skillSelection);
    setSkillsBusy(false);
    if (result.ok) setSkillsOpen(false);
    else setSkillsError(result.error);
  }

  return (
    <div className="profile">
      <div className="profile__header">
        <div className="profile__avatar" aria-hidden="true" />
        <div>
          <h1>{player.name}</h1>
          <p className="profile__meta">
            Станция: {player.faction} • Ур. {player.level || 1}
          </p>
        </div>
        <div className="profile__badges">
          <span className="profile__level">{player.level || 1}</span>
          <span className="profile__class">{ZONE_LABEL[player.zone] || "—"}</span>
        </div>
      </div>

      <div className="profile__currency">
        <span>💳 {(player.credits || 0).toLocaleString("ru-RU")}</span>
      </div>

      <section className="profile__panel">
        <div className="profile__xpHead">
          <span>Опыт</span>
          <span>{player.xp || 0} / {next} XP</span>
        </div>
        <div className="profile__xpBar">
          <div className="profile__xpFill" style={{ width: `${xpPercent}%` }} />
        </div>
      </section>

      <section className="profile__panel profile__stats">
        <div>
          <span className="profile__statLabel">HP</span>
          <strong>{player.hp}/{player.hpMax}</strong>
        </div>
        <div>
          <span className="profile__statLabel">Репутация</span>
          <strong>{player.reputation || 0}</strong>
        </div>
        <div>
          <span className="profile__statLabel">Облучение</span>
          <strong>{player.radiation || 0}%</strong>
        </div>
      </section>

      <section className="profile__panel">
        <h4>
          Характеристики
          {player.statPoints > 0 && (
            <span className="profile__statPoints"> · {player.statPoints} свободно</span>
          )}
        </h4>
        <div className="profile__attrGrid">
          {Object.entries(STAT_LABELS).map(([key, label]) => (
            <div key={key} className="profile__attrRow">
              <span>{label}</span>
              <div className="profile__attrValue">
                <strong>{player.stats?.[key]}</strong>
                {player.statPoints > 0 && (
                  <button
                    type="button"
                    className="profile__statPlus"
                    disabled={statBusy === key}
                    onClick={() => handleAllocate(key)}
                    aria-label={`Добавить очко в ${label}`}
                  >
                    {statBusy === key ? "…" : "+"}
                  </button>
                )}
              </div>
            </div>
          ))}
          <div className="profile__attrRow">
            <span>Огневая мощь</span>
            <strong>{player.stats?.firepower}</strong>
          </div>
          <div className="profile__attrRow">
            <span>Защита</span>
            <strong>{player.stats?.shielding}</strong>
          </div>
        </div>
      </section>

      <section className="profile__panel">
        <div className="profile__skillsHead">
          <h4>Экипированные умения</h4>
          <button type="button" className="profile__editSkills" onClick={openSkillEditor}>
            Изменить
          </button>
        </div>
        {equippedSkillNames.length > 0 ? (
          <div className="profile__rewards">
            {equippedSkillNames.map((name) => (
              <span key={name}>{name}</span>
            ))}
          </div>
        ) : (
          <p className="profile__emptyNote">Умения не выбраны.</p>
        )}
      </section>

      {skillsOpen && (
        <div className="profile__modalOverlay" onClick={() => setSkillsOpen(false)}>
          <div className="profile__modal" onClick={(e) => e.stopPropagation()}>
            <h4>
              Выбор умений
              <span className="profile__statPoints">
                {" "}· {skillSelection.length}/{maxEquippedSkills || 3}
              </span>
            </h4>
            <div className="profile__skillList">
              {(allSkills || []).map((skill) => {
                const active = skillSelection.includes(skill.id);
                return (
                  <button
                    type="button"
                    key={skill.id}
                    className={`profile__skillOption ${active ? "profile__skillOption--active" : ""}`}
                    onClick={() => toggleSkill(skill.id)}
                  >
                    <span>{skill.name}</span>
                    <span className="profile__skillStation">{skill.station}</span>
                  </button>
                );
              })}
            </div>
            {skillsError && <p className="profile__state--error">{skillsError}</p>}
            <div className="profile__modalActions">
              <button type="button" className="ghost" onClick={() => setSkillsOpen(false)}>
                Отмена
              </button>
              <button type="button" disabled={skillsBusy} onClick={saveSkills}>
                {skillsBusy ? "Сохранение..." : "Сохранить"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
