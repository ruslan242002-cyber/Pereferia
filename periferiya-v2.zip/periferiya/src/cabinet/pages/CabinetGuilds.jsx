import "./CabinetPlaceholder.css";

export default function CabinetGuilds() {
  return (
    <div className="cabinetPlaceholder">
      <h1>ФРАКЦИИ</h1>
      <p>Информация о фракциях «Периферии», вступление и внутренняя иерархия.</p>
      <div className="cabinetPlaceholder__soon">Раздел в разработке</div>
    </div>
  );
}
