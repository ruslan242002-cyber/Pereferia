import "./CabinetPlaceholder.css";

export default function CabinetRatings() {
  return (
    <div className="cabinetPlaceholder">
      <h1>РЕЙТИНГИ</h1>
      <p>Таблицы лидеров по опыту, репутации и достижениям станций.</p>
      <div className="cabinetPlaceholder__soon">Раздел в разработке</div>
    </div>
  );
}
