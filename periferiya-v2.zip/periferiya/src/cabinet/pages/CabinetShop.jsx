import "./CabinetPlaceholder.css";

export default function CabinetShop() {
  return (
    <div className="cabinetPlaceholder">
      <h1>МАГАЗИН</h1>
      <p>Покупка снаряжения, ресурсов и косметики за внутриигровую валюту.</p>
      <div className="cabinetPlaceholder__soon">Раздел в разработке</div>
    </div>
  );
}
