// VK Mini App при запуске добавляет к URL сайта параметры вида
// ?vk_user_id=...&sign=...&vk_app_id=... — profile-handler.js на бэкенде
// проверяет их ПОДПИСЬ целиком (verifyLaunchParams), поэтому сюда нельзя
// доставать только vk_user_id: нужно переслать всю query-строку как есть,
// иначе проверка подписи не сойдётся.
import { useMemo } from "react";

export function useVkLaunchParams() {
  return useMemo(() => {
    const search = window.location.search.replace(/^\?/, "");
    const params = new URLSearchParams(search);
    return {
      // Сырая строка целиком — то, что уходит в api/profile.js как ?launch=
      raw: search,
      hasVkUserId: params.has("vk_user_id"),
    };
  }, []);
}
