import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import Particles from "./Particles";
import "./Hero.css";

export default function Hero() {
  return (
    <section className="hero">
      <Particles />
      <div className="hero__stars"></div>
      <div className="hero__nebula"></div>
      <div className="hero__planet"></div>
      <div className="hero__grid"></div>

      <motion.div
        className="hero__content"
        initial={{ opacity: 0, y: 80 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
      >
        <motion.span
          className="hero__badge"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: .3 }}
        >
          MMORPG • SCI-FI • SANDBOX
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, scale: .95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: .4 }}
        >
          ПЕРИФЕРИЯ
        </motion.h1>

        <motion.div
          className="title-line"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: .8 }}
        >
          <span></span>
          <b>КОСМИЧЕСКАЯ ТЕКСТОВАЯ MMO</b>
          <span></span>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          Исследуй далёкие системы. Создавай собственную империю. Торгуй,
          воюй, открывай неизведанные миры. Каждый игрок способен изменить
          историю галактики.
        </motion.p>

        <motion.div
          className="heroButtons"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3 }}
        >
          <Link className="heroPrimary" to="/download">
            НАЧАТЬ ИГРУ
          </Link>
          <Link className="heroSecondary" to="/world">
            ИССЛЕДОВАТЬ МИР
          </Link>
        </motion.div>

        <motion.div
          className="heroStats"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6 }}
        >
          <div>
            <strong>500+</strong>
            <span>ЛОКАЦИЙ</span>
          </div>
          <div>
            <strong>120+</strong>
            <span>КОРАБЛЕЙ</span>
          </div>
          <div>
            <strong>∞</strong>
            <span>ВОЗМОЖНОСТЕЙ</span>
          </div>
        </motion.div>
      </motion.div>

      <div className="heroShip heroShip1"></div>
      <div className="heroShip heroShip2"></div>

      <div className="hero__scroll">
        <span></span>
      </div>
    </section>
  );
}
