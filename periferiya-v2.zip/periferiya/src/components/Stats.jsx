import "./Stats.css";

const stats = [
  { value: "1287+", label: "АКТИВНЫХ ИГРОКОВ" },
  { value: "42", label: "ФРАКЦИИ" },
  { value: "3200+", label: "СИСТЕМ" },
  { value: "∞", label: "ВОЗМОЖНОСТЕЙ" },
];

export default function Stats() {
  return (
    <section className="stats">
      {stats.map((stat) => (
        <div className="stats__item" key={stat.label}>
          <strong>{stat.value}</strong>
          <span>{stat.label}</span>
        </div>
      ))}
    </section>
  );
}
