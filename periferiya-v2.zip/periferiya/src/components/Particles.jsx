import { useMemo } from "react";
import "./Particles.css";

const COUNT = 40;

export default function Particles() {
  // Math.random() зафиксирован через useMemo один раз на весь жизненный
  // цикл компонента — иначе частицы дёргались бы при любом ре-рендере родителя.
  const particles = useMemo(
    () =>
      Array.from({ length: COUNT }).map(() => ({
        left: `${Math.random() * 100}%`,
        animationDelay: `${Math.random() * 15}s`,
        animationDuration: `${10 + Math.random() * 20}s`,
      })),
    []
  );

  return (
    <div className="particles" aria-hidden="true">
      {particles.map((style, i) => (
        <span key={i} style={style}></span>
      ))}
    </div>
  );
}
