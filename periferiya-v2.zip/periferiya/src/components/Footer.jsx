import { Link } from "react-router-dom";
import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-left">
        <h2>ПЕРИФЕРИЯ</h2>
        <p>Текстовая космическая MMORPG нового поколения.</p>
      </div>
      <nav className="footer-links" aria-label="Навигация по сайту">
        <h4>Навигация</h4>
        <Link to="/">Главная</Link>
        <Link to="/world">Мир</Link>
        <Link to="/news">Новости</Link>
        <Link to="/ships">Корабли</Link>
      </nav>
      <nav className="footer-links" aria-label="Сообщество">
        <h4>Сообщество</h4>
        {/* TODO: заменить на реальные ссылки сообществ, когда они будут под рукой */}
        <a href="https://discord.gg/periferia" target="_blank" rel="noreferrer">Discord</a>
        <a href="https://t.me/periferia_mmo" target="_blank" rel="noreferrer">Telegram</a>
        <a href="https://vk.com/periferia_mmo" target="_blank" rel="noreferrer">VK</a>
      </nav>
      <div className="footer-copy">© 2026 ПЕРИФЕРИЯ</div>
    </footer>
  );
}
