import { useEffect, useState } from "react";
import "./ScrollTop.css";

export default function ScrollTop() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const scroll = () => {
      setShow(window.scrollY > 500);
    };
    window.addEventListener("scroll", scroll);
    return () => window.removeEventListener("scroll", scroll);
  }, []);

  return (
    <button
      className={`scrollTop ${show ? "active" : ""}`}
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="Наверх страницы"
      aria-hidden={!show}
      tabIndex={show ? 0 : -1}
    >
      ↑
    </button>
  );
}
