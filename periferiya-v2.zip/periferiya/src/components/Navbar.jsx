import { NavLink } from "react-router-dom";
import { useEffect, useState } from "react";
import "./Navbar.css";

const NAV_LINKS = [
  { to: "/", label: "Главная" },
  { to: "/world", label: "Мир" },
  { to: "/factions", label: "Фракции" },
  { to: "/ships", label: "Корабли" },
  { to: "/news", label: "Новости" },
  { to: "/community", label: "Сообщество" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Закрыть по Escape — стандартное ожидание для любого выезжающего меню.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  // Пока меню открыто на телефоне, страница за ним не должна скроллиться.
  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`navbar ${scrolled ? "navbar--scrolled" : ""}`}>
      <div className="navbar__inner">
        <NavLink to="/" className="brand" onClick={closeMenu}>
          ПЕРИФЕРИЯ
        </NavLink>

        <nav className="nav">
          {NAV_LINKS.map((link) => (
            <NavLink key={link.to} to={link.to}>
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="auth">
          <NavLink to="/login" className="button button--ghost">
            Войти
          </NavLink>
          <NavLink to="/register" className="button button--outline">
            Регистрация
          </NavLink>
        </div>

        <button
          type="button"
          className={`burger ${menuOpen ? "burger--active" : ""}`}
          onClick={() => setMenuOpen((v) => !v)}
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          aria-label={menuOpen ? "Закрыть меню" : "Открыть меню"}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>

      <div
        id="mobile-menu"
        className={`mobileMenu ${menuOpen ? "mobileMenu--open" : ""}`}
        aria-hidden={!menuOpen}
      >
        <nav className="mobileMenu__links">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={closeMenu}
              tabIndex={menuOpen ? 0 : -1}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className="mobileMenu__auth">
          <NavLink
            to="/login"
            className="button button--ghost"
            onClick={closeMenu}
            tabIndex={menuOpen ? 0 : -1}
          >
            Войти
          </NavLink>
          <NavLink
            to="/register"
            className="button button--outline"
            onClick={closeMenu}
            tabIndex={menuOpen ? 0 : -1}
          >
            Регистрация
          </NavLink>
        </div>
      </div>
    </header>
  );
}
