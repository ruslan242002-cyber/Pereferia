import { motion } from "framer-motion";
import "./About.css";

const cards = [
  {
    title: "Живой мир",
    text: "Каждое действие игроков влияет на развитие галактики и изменяет историю."
  },
  {
    title: "Фракции",
    text: "Выбирай сторону конфликта или создай собственную организацию."
  },
  {
    title: "Экономика",
    text: "Игроки формируют рынок, производят товары и контролируют торговые пути."
  },
  {
    title: "Исследование",
    text: "Открывай новые системы, станции и неизведанные регионы космоса."
  }
];

export default function About() {
  return (
    <section className="about" id="about">
      <div className="about__header">
        <span className="sectionTag">ВСЕЛЕННАЯ</span>
        <h2>Мир, который развивается вместе с игроками</h2>
        <p>
          «Периферия» — это космическая MMORPG с упором на свободу действий,
          исследование, торговлю, политику и взаимодействие между игроками.
          Здесь нет заранее написанного финала — историю создаёт само
          сообщество.
        </p>
      </div>

      <div className="aboutGrid">
        {cards.map((card, index) => (
          <motion.article
            key={card.title}
            className="aboutCard"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: .6, delay: index * .15 }}
          >
            <div className="aboutCard__number">0{index + 1}</div>
            <h3>{card.title}</h3>
            <p>{card.text}</p>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
