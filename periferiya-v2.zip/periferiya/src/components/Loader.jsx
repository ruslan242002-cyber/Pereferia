import { useEffect, useState } from "react";
import "./Loader.css";

const DISPLAY_MS = 2200;
const EXIT_MS = 500; // должно совпадать с длительностью transition в Loader.css

export default function Loader({ children }) {
  const [phase, setPhase] = useState("loading"); // loading -> exiting -> done

  useEffect(() => {
    const timer = setTimeout(() => setPhase("exiting"), DISPLAY_MS);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (phase !== "exiting") return;
    const timer = setTimeout(() => setPhase("done"), EXIT_MS);
    return () => clearTimeout(timer);
  }, [phase]);

  if (phase === "done") return children;

  return (
    <div
      className={`loader ${phase === "exiting" ? "loader--exiting" : ""}`}
      role="status"
      aria-live="polite"
      aria-busy="true"
    >
      <div className="loaderPlanet" aria-hidden="true"></div>
      <h1>ПЕРИФЕРИЯ</h1>
      <p>ИНИЦИАЛИЗАЦИЯ ГАЛАКТИКИ...</p>
    </div>
  );
}
