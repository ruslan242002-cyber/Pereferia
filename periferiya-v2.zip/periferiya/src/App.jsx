import { Routes, Route } from "react-router-dom";
import Loader from "./components/Loader";
import MouseLight from "./components/MouseLight";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ScrollTop from "./components/ScrollTop";

import Home from "./pages/Home";
import World from "./pages/World";
import Factions from "./pages/Factions";
import Ships from "./pages/Ships";
import News from "./pages/News";
import Community from "./pages/Community";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Download from "./pages/Download";

import CabinetLayout from "./cabinet/CabinetLayout";
import Profile from "./cabinet/pages/Profile";
import CabinetMap from "./cabinet/pages/CabinetMap";
import CabinetShop from "./cabinet/pages/CabinetShop";
import CabinetWorkbench from "./cabinet/pages/CabinetWorkbench";
import CabinetRatings from "./cabinet/pages/CabinetRatings";
import CabinetGuilds from "./cabinet/pages/CabinetGuilds";
import CabinetCodex from "./cabinet/pages/CabinetCodex";
import CabinetSettings from "./cabinet/pages/CabinetSettings";

// Обёртка с маркетинговой навигацией (Navbar/Footer) — используется только
// для лендинга. Личный кабинет (/cabinet/*) рендерится без неё, у него
// собственная оболочка с боковым меню (CabinetLayout).
function MarketingLayout({ children }) {
  return (
    <>
      <MouseLight />
      <Navbar />
      <main>{children}</main>
      <Footer />
      <ScrollTop />
    </>
  );
}

export default function App() {
  return (
    <Loader>
      <Routes>
        <Route path="/" element={<MarketingLayout><Home /></MarketingLayout>} />
        <Route path="/world" element={<MarketingLayout><World /></MarketingLayout>} />
        <Route path="/factions" element={<MarketingLayout><Factions /></MarketingLayout>} />
        <Route path="/ships" element={<MarketingLayout><Ships /></MarketingLayout>} />
        <Route path="/news" element={<MarketingLayout><News /></MarketingLayout>} />
        <Route path="/community" element={<MarketingLayout><Community /></MarketingLayout>} />
        <Route path="/login" element={<MarketingLayout><Login /></MarketingLayout>} />
        <Route path="/register" element={<MarketingLayout><Register /></MarketingLayout>} />
        <Route path="/download" element={<MarketingLayout><Download /></MarketingLayout>} />

        <Route path="/cabinet" element={<CabinetLayout />}>
          <Route index element={<Profile />} />
          <Route path="map" element={<CabinetMap />} />
          <Route path="shop" element={<CabinetShop />} />
          <Route path="workbench" element={<CabinetWorkbench />} />
          <Route path="ratings" element={<CabinetRatings />} />
          <Route path="guilds" element={<CabinetGuilds />} />
          <Route path="codex" element={<CabinetCodex />} />
          <Route path="settings" element={<CabinetSettings />} />
        </Route>
      </Routes>
    </Loader>
  );
}
