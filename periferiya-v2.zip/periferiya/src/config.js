// Сайт и api/profile.js живут на одном домене (один проект на Vercel),
// поэтому достаточно относительного пути — CORS не нужен.
export const API_BASE_URL = "/api";
